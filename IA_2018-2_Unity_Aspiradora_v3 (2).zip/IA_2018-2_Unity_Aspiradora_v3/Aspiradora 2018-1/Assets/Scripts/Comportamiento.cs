﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Script que otorga funcionalidad o comportamiento al agente.
// Utiliza la información/métodos de los script de sensores y actuadores para tomar decisiones.
public class Comportamiento : MonoBehaviour {

	private Sensores sensor;
	private Actuadores actuador;
	public float bateria; // Tiempo de vida (aproximado en segundos)
	public float maxBateria; // Capacidad máxima de la batería

	void Start(){
		sensor = GetComponent<Sensores>();
		actuador = GetComponent<Actuadores>();
	}

	// En cada frame decidimos el comportamiento del agente.
	// Para este caso, tenemos un control "manual" del agente, es decir, un usuario puede controlarlo mediante
	// un control/gamepad o flechas del teclado y imprime información en consola.
	void Update(){
		// La batería se consume lentamente. En caso de que se termine, no realiza ninguna acción
		if(bateria <= 0)
			return;
		else
			bateria -= Time.deltaTime;
		// Recargar batería al contacto, sin rebasar límite de carga
		if(sensor.TocandoEstacion() && bateria < maxBateria)
			bateria += Time.deltaTime * 2;

		if(Input.GetKeyDown(KeyCode.UpArrow) || Input.GetAxis("Vertical") == 1)
			actuador.MoverAdelante();
		if(Input.GetKeyDown(KeyCode.DownArrow) || Input.GetAxis("Vertical") == -1)
			actuador.MoverAtras();
		if(Input.GetKeyDown(KeyCode.RightArrow) || Input.GetAxis("Horizontal") == 1)
			actuador.GirarDerecha();
		if(Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetAxis("Horizontal") == -1)
			actuador.GirarIzquierda();

		if(sensor.TocandoPared())
			Debug.Log("Tocando pared");
		if(sensor.TocandoBasura())
			Debug.Log("Tocando basura");
		if(sensor.CercaDeBasura())
			Debug.Log("Cerca de basura");
		if(sensor.CercaDePared())
			Debug.Log("Cerca de pared");
		if (sensor.FrenteBasura())
			Debug.Log("Frente a basura");
		if (sensor.FrentePared())
			Debug.Log("Frente a pared");
	}
}
