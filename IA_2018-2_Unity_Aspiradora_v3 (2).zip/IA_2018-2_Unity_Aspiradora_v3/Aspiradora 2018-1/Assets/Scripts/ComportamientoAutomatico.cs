﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Ejemplo de un comportamiento automático para el agente
public class ComportamientoAutomatico : MonoBehaviour {

	private Sensores sensor;
    private bool flag = true;
	private Actuadores actuador;
	public float bateria; // Tiempo de vida (aproximado en segundos)
	public float maxBateria; // Capacidad máxima de la batería

	void Start(){
		sensor = GetComponent<Sensores>();
		actuador = GetComponent<Actuadores>();
	}

    void Update() {
        // La batería se consume lentamente. En caso de que se termine, no realiza ninguna acción
        if (bateria <= 0)
            return;
        else
            bateria -= Time.deltaTime;
        // Recargar batería al contacto, sin rebasar límite de carga
        if (sensor.TocandoEstacion() && bateria < maxBateria)
            bateria += Time.deltaTime * 2;

        // A partir de aquí se puede implementar el comportamiento automático usando sensor y actuador
        // Este ejemplo básico mueve al agente hacia adelante hasta que esté cerca de una pared
        if (!sensor.TocandoPared()&&flag)
        {
            actuador.MoverAdelante();
            if (sensor.CercaDeEstacion())
            {
                Vector3 posEstacion = sensor.GetPosicionEstacion();
                if (!sensor.FrenteEstacion()&&!sensor.TocandoEstacion())
                    actuador.GirarDerecha();
                

                if (!sensor.TocandoEstacion())
                {
                    actuador.MoverAdelante();
                    flag = false;

                }
                

            }
            else actuador.MoverAdelante();
        }
        else if(flag)actuador.GirarDerecha();
    

    }
}
